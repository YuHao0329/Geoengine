%% Map Projection Lab11
%% Yu-Hao Chiang 3443130
close all
clear all
clc
%% Prepare data
% Obtain long, lat coastline 
load('coast.mat')
long(long < -180) = long(long < -180) + 360;
long(long >= 180) = long(long >= 180) - 360;
[long,lat] = jump2nan(long, 180, lat);
R = 1;        % radius 
% central point
lambda0 = 0;
phi1 = 0;
%% Task 2 
% define longitude and latitude grid
lambda_init = [-180: 10: 180];
phi_init = [-85: 10: 85];

% parallels
[lambda_p, phi_p] = meshgrid(linspace(min(lambda_init), max(lambda_init), 720), phi_init);
% meridians
[lambda_m, phi_m] = meshgrid(lambda_init, linspace(min(phi_init), max(phi_init), 720));

[x, y] = mercator_pro(long, lat, lambda0, phi1);
[mx, my] = mercator_pro(lambda_m, phi_m, lambda0, phi1);
[px, py] = mercator_pro(lambda_p', phi_p', lambda0, phi1);

figure
plot(x, y)
hold on
axis equal
axis off
xlim([-pi, pi])
plot(mx, my, 'k')
plot(px, py, 'k')

bb = -85:10:85;
b_cell = num2cell(bb)';
G_bar = cellfun(@(i) R^2 * [cosd(i).^2, 0; 0, 1], b_cell, 'UniformOutput', false);
g = [1, 0; 0, 1];
J_bar = cellfun(@Jacobi_mercator, num2cell(zeros(size(b_cell, 1), 1)), b_cell, 'UniformOutput', false);
C_bar = cellfun(@(J, g) J'*g*J, J_bar, mat2cell(repmat(g, size(b_cell, 1), 1), repmat(2, size(b_cell, 1), 1), 2), 'UniformOutput', false);
[F, D] = cellfun(@eig, C_bar, G_bar, 'UniformOutput', false);
f = cellfun(@(J, F) J*F, J_bar, F, 'UniformOutput', false);
a = cellfun(@(D) sqrt(D(2, 2)), D);
b = cellfun(@(D) sqrt(D(1, 1)), D);
beta = cellfun(@(f) atan2(f(2, 2), f(1, 2)), f);

[lon, lat] = meshgrid(-180:30:180, bb);
[x_ellip, y_ellip] = mercator_pro(lon, lat, lambda0, phi1);
sz1 = size(x_ellip, 1);
sz2 = size(x_ellip, 2);
a = reshape(a*ones(1, sz2)*0.05, sz1 * sz2, 1);
b = reshape(b*ones(1, sz2)*0.05, sz1 * sz2, 1);
beta = reshape(beta*ones(1, sz2), sz1 * sz2, 1);
x_ellip = reshape(x_ellip, sz1 * sz2, 1);
y_ellip = reshape(y_ellip, sz1 * sz2, 1);
ellipse(a, b, beta, x_ellip, y_ellip, 'r');
title('Tissot ellipses of Mercator projection')
%% Task 3
clear 
R = 1;        % radius
phi = [0: 70]';
phi = num2cell(phi);
 
G_bar = cellfun(@(i) R^2 * [cosd(i).^2, 0; 0, 1], phi, 'UniformOutput', false);
g = [1, 0; 0, 1];
J_bar = cellfun(@Jacobi_mercator, num2cell(zeros(size(phi, 1), 1)), phi, 'UniformOutput', false);
C_bar = cellfun(@(J, g) J'*g*J, J_bar, mat2cell(repmat(g, size(phi, 1), 1), repmat(2, size(phi, 1), 1), 2), 'UniformOutput', false);
[F, D] = cellfun(@eig, C_bar, G_bar, 'UniformOutput', false);
f = cellfun(@(J, F) J*F, J_bar, F, 'UniformOutput', false);
a = cellfun(@(D) sqrt(D(2, 2)), D);
b = cellfun(@(D) sqrt(D(1, 1)), D);

airy_local = ((a-1).^2 + (b-1).^2) / 2;
airy_global = cumsum(airy_local .* cosd([0: 70]')) ./ (1:length([0: 70]'))';

figure
plot([60: 70], airy_local(61:71))
hold on
plot([60: 70], airy_global(61:71))
legend("Local", "Global")
title("Airy criterion")