function J = Jacobi_mercator(lambda, phi)
lambda = lambda.*pi./180;
phi = phi.*pi./180;

J = [1, 0;
     0, 1./(2.*tan(pi/4 + 1/2.*phi).*cos(pi/4 + 1/2.*phi).^2)];

end