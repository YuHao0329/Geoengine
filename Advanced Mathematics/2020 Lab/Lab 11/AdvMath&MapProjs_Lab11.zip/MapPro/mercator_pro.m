function [x, y] = mercator_pro(Lambda, Phi, lambda0, phi1)
x = Lambda.*pi./180 - lambda0.*pi./180;
y = log(tan(1/4*pi + 1/2*Phi.*pi./180));
% y = log(tan(Phi.*pi./180) + sec(Phi.*pi./180));
end