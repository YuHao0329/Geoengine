%% Map Projections Lab 2 
%% Yu-Hao Chiang 3443130
%% General Element
close all
clear all
clc
% FOR THE VISUALIZATION
% create a representation of the Earth => represent a meridian line
% => create a semi-circle (one half of a meridian line, so lambda fixed)
radius     = 1;
phi        = -pi/2 : pi/90 : pi/2;
delta_phi  = pi/12;
x          = radius * cos(phi);
y          = radius * sin(phi);
% FOR THE DISTORTION
% compute the arc length between the rays intersecting the sphere
circum     = 2 * pi * radius;
arc_length = circum * (delta_phi / (2 * pi));
%% Task 1 (Cylindrical Projection)

% develop the surface cylinder
radius_cyl = radius+1;
x0_cyl     = radius_cyl * cos(phi);
y0_cyl     = radius_cyl * sin(phi);

figure(1)
box on
plot(x, y, 'k-', 'linewidth', 2) 
hold on
axis equal
plot(x0_cyl, y0_cyl, 'k-', 'linewidth', 2)
plot(0, 0, 'k+', 'linewidth', 2)
grid on
title('Cylindrical Projection', 'fontsize', 16)

% add rays to visualize the projection -> check the equations definition
ray_phi_cyl = -pi/2 : delta_phi : pi/2;
ray_x_cyl   = radius_cyl * cos(ray_phi_cyl);
ray_y_cyl   = radius_cyl * sin(ray_phi_cyl);
% ray_y_cyl   = ray_x_cyl .* tan(ray_phi_cyl);
plot([0 * ray_x_cyl; ray_x_cyl], [0 * ray_y_cyl; ray_y_cyl], 'g--', 'linewidth', 1)

% The cylinder is tangent to the reference surface of the Earth. 
% Its circumference touches the surface along a great circle.
% The diameter of the cylinder is equal to the diameter of the globe. 
% The tangent line is the equator.
%% Task 2 (Cylindrical Projection - Distortions)
% radius should be 1 in reality (it is just to visualize)
% compute the distortion
scale = arc_length / arc_length;

figure(2)
box on
% on x, because we stay on the same tangent plan -> we create a vector of ones
xs1 = scale .* ones(length(ray_phi_cyl) - 1);
% on y, because we calculate each distortion btw rays from the center of the earth
ys1 = 180 .* (ray_phi_cyl(1 : end-1) + delta_phi / 2) ./ pi;
plot(xs1, ys1, 'bo-', 'linewidth', 1)
xlabel('scale', 'fontsize', 15)
ylabel('degree', 'fontsize', 15)
grid on
title('Distortions of the Cylindrical Projection','fontsize',16)
axis equal

% The tangent lines are important since scale is constant along these lines.
% Thus, there is no distortion (scale factor = 1). 
% Then, distortion increases by moving away from these standard lines (to the poles).
%% Task 3 (Gnomonic Projection)
figure(3)
box on
plot(x, y, 'k-', 'linewidth', 2) 
hold on
axis equal
plot(0, 0, 'k+', 'linewidth', 2)
plot([1,1],[-2,2],'k', 'linewidth', 2)
grid on
title('Gnomonic Projection', 'fontsize', 16)

% add rays to visualize the projection -> check the equations definition
radius_gno = 1;
ray_phi_gno = -pi/2 + delta_phi*2  : delta_phi : pi/2 - delta_phi*2;
ray_x_gno   = radius_gno * cos(ray_phi_gno);
ray_y_gno   = radius_gno * sin(ray_phi_gno);
plot([0 * ray_x_gno; ones(1,9)], [0 * ray_y_gno; ray_y_gno./ray_x_gno], 'g--', 'linewidth', 1)
%% Task 4 (Gnomonic Projection - Distortions)
% FOR THE DISTORTION
% compute the arc length between the rays intersecting the sphere
circum     = 2 * pi * radius;
arc_length = circum * (delta_phi / (2 * pi));
p = ray_y_gno./ray_x_gno; % the point on the projection plane
i = 0;
 for i = 1:8
     d(i) = p(i+1) - p(i); % the distance between two points on the plane
 end
% compute the scale 
scale_gno = d / arc_length;

figure(4)
box on
xs2 = scale_gno .* ones(1,length(ray_phi_gno) - 1);
ys2 = 180 .* (ray_phi_gno(1 : end-1) + delta_phi / 2) ./ pi;
plot(xs2, ys2, 'bo-', 'linewidth', 1)
xlabel('scale', 'fontsize', 15)
xlim([0 4])
ylabel('degree', 'fontsize', 15)
grid on
title('Distortions of the Gnomonic Projection','fontsize',16)


%% Task 5 (Orthographic Projection)
figure(5)
box on
plot(x, y, 'k-', 'linewidth', 2) 
hold on
axis equal
plot(0, 0, 'k+', 'linewidth', 2)
plot([1,1],[-1,1],'k', 'linewidth', 2)
grid on
title('Orthographic Projection', 'fontsize', 16)
% add rays to visualize the projection
ray_y_ort = linspace(-1,1,11);
plot([zeros(1,11) ; ones(1,11)], [ray_y_ort ; ray_y_ort], 'g--', 'linewidth', 1)
%% Task 6 (Stereographic Projection)
figure(6)
box on
X = 0;
Y = 0;
r = 1;
phi = 0 : pi/50 : 2*pi;
xunit = r * cos(phi) + X;
yunit = r * sin(phi) + Y;
plot(xunit, yunit, 'k-', 'linewidth', 2)
hold on
plot(-1, 0, 'k+', 'linewidth', 2)
plot([1,1],[-2, 2],'k', 'linewidth', 2)
axis equal
grid on
title('Stereographic Projection', 'fontsize', 16)

% add rays to visualize the projection -> check the equations definition
radius_ste  = 2;
ray_phi_ste = -pi/2 + delta_phi*2  : delta_phi : pi/2 - delta_phi*2;
ray_x_ste   = radius_ste * cos(ray_phi_ste);
ray_y_ste   = radius_ste * sin(ray_phi_ste);
plot([-1*ones(1,9); ones(1,9)], [0 * ray_y_ste; 2 * ray_y_ste ./ (ray_x_ste + 1)], 'b--', 'linewidth', 1)
%% Task 7 (Conic Projection)
figure(7)
box on
plot(x, y, 'k-', 'linewidth', 2) 
hold on
plot(0, 0, 'k+', 'linewidth', 2)
plot([0, 2], [-2*sqrt(3)/3, 0],'k', 'linewidth', 2)
plot([2, 0], [0, 2*sqrt(3)/3],'k', 'linewidth', 2)
axis equal
grid on
title('Conic Projection', 'fontsize', 16)

% add rays to visualize the projection -> check the equations definition
radius_con  = 2;
delta_phi = pi/22;
ray_phi_con_upper = 0 : delta_phi/2 : pi/2 ;
ray_phi_con_bottom = -pi/2 : delta_phi/2 : 0 ;
ray_x_con_upper    = radius_con * cos(ray_phi_con_upper);
ray_y_con_upper    = radius_con * sin(ray_phi_con_upper);
ray_x_con_bottom   = radius_con * cos(ray_phi_con_bottom);
ray_y_con_bottom   = radius_con * sin(ray_phi_con_bottom);
a = (2/3*sqrt(3))./(ray_y_con_upper./ray_x_con_upper + sqrt(3)/3);
b = (2/3*sqrt(3))./((ray_y_con_bottom.*(-1))./ray_x_con_bottom + sqrt(3)/3);
plot([0*ray_x_con_upper ; a], [0 * ray_y_con_upper; ray_y_con_upper./ray_x_con_upper .* a], 'g--', 'linewidth', 1)
plot([0*ray_x_con_bottom ; b], [0 * ray_y_con_bottom; ray_y_con_bottom./ray_x_con_bottom .* b], 'g--', 'linewidth', 1)

