function [x, y] = miller_cylindrical(long, lat, lambda0, phi0)

% cylindrical inserts specific value in order to compute the coordinates in
% miller cylindrical projection
%          
% HOW     
%     [x, y] = miller_cylindrical(long, lat, lambda0, phi0)
%
% IN  
%     long - longtitude values
%     lat  - latitude values 
%     lambda0 - lambda value in central point
%     phi0 - phi value in central point
% OUT 
%     x   - x coordinate in cylindrical projection
%     y   - y coordinate in cylindrical projection
%
%-----------------------------------------------------------------------
% Yu-Hao Chiang         University of Stuttgart               25/11/2020
%-----------------------------------------------------------------------
% Here we go
x = (long - lambda0);
y = 5/4*(asinh(tand(4/5*lat)))/pi*180;


end