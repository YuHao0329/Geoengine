function [x, y] = cylindrical(long, lat, lambda0, phi0)

% cylindrical inserts specific value in order to compute the coordinates in
% cylindrical projection
%          
% HOW     
%     [x, y] = cylindrical(long, lat, lambda0, phi0)
%
% IN  
%     long - longtitude values
%     lat  - latitude values 
%     lambda0 - lambda value in central point
%     phi0 - phi value in central point
% OUT 
%     x   - x coordinate in cylindrical projection
%     y   - y coordinate in cylindrical projection
%
%-----------------------------------------------------------------------
% Yu-Hao Chiang         University of Stuttgart               25/11/2020
%-----------------------------------------------------------------------
% Here we go
x = long - lambda0;
y = tand(lat - phi0)/pi*180;



end

