%% Map projection Lab 3
%% Yu-Hao Chiang 3443130
close all
clear all
clc
%% Prepare data
% Obtain long, lat coastline 
load('coast.mat')
[long,lat] = jump2nan(long, 180, lat);

% central point
lambda0 = 0;
phi0 = 0;

% coordinate of the cities
% Stuttgart
long_Stuttgart = 9.183333;       %[degree]
lat_Stuttgart  = 48.783333;      %[degree]

% Taipei
long_Taipei = 121.597366;        %[degree]
lat_Taipei  =  25.105497;        %[degree]

% New York
long_NewYork = -73.935242;       %[degree]
lat_NewYork = 40.730610;         %[degree]

% Perth
long_Perth = 115.857048;         %[degree]
lat_Perth = -31.953512;          %[degree]

%% Cylindrical Projection
long_c = long;
lat_c = lat;
% initial value
lambda_init = [-180: 30: 180];
phi_init    = [-90: 15: 90];

% meridians 
[lambda, phi] = meshgrid(lambda_init, linspace(min(phi_init), max(phi_init), 40));
% parallels
[Lambda, Phi] = meshgrid(linspace(min(lambda_init), max(lambda_init), 40), phi_init);

% central coordinate in cylindrical projection
[xc, yc]             = cylindrical(long, lat, lambda0, phi0);
[xc_m, yc_m]         = cylindrical(lambda, phi, lambda0, phi0);
[xc_p, yc_p]         = cylindrical(Lambda, Phi, lambda0, phi0);

% cities coordinate (Stuttgart, Taipei, New York, Perth) in cylindrical projection
[xc_Stu, yc_Stu]     = cylindrical(long_Stuttgart, lat_Stuttgart, lambda0, phi0);
[xc_Tai, yc_Tai]     = cylindrical(long_Taipei, lat_Taipei, lambda0, phi0);
[xc_NY, yc_NY]       = cylindrical(long_NewYork, lat_NewYork, lambda0, phi0);
[xc_Per, yc_Per]     = cylindrical(long_Perth, lat_Perth, lambda0, phi0);

% central angle between Stuttgart and each three other cities
% sigma_Stu2Tai = acos(sind(lat_Stuttgart)*sind(lat_Taipei) + cosd(lat_Stuttgart)*cosd(lat_Taipei)*cosd(long_Stuttgart - long_Taipei))/ pi * 180;
% sigma_Stu2NY  = acos(sind(lat_Stuttgart)*sind(lat_NewYork) + cosd(lat_Stuttgart)*cosd(lat_NewYork)*cosd(long_Stuttgart - long_NewYork))/ pi * 180;
% sigma_Stu2Per = acos(sind(lat_Stuttgart)*sind(lat_Perth) + cosd(lat_Stuttgart)*cosd(lat_Perth)*cosd(long_Stuttgart - long_Perth))/ pi * 180;
% actual arc length
% r = 1 ;% radius of the sphere
% d_Stu2Tai = r * sigma_Stu2Tai;
% d_Stu2NY = r * sigma_Stu2NY;
% d_Stu2Per = r * sigma_Stu2Per;

% compute the distance
dc_Tai2Stu = sqrt(((xc_Tai - xc_Stu)*pi/180)^2 + ((yc_Tai - yc_Stu)*pi/180)^2);
dc_NY2Stu = sqrt(((xc_NY - xc_Stu)*pi/180)^2 + ((yc_NY - yc_Stu)*pi/180)^2);
dc_Per2Stu = sqrt(((xc_Per - xc_Stu)*pi/180)^2 + ((yc_Per - yc_Stu)*pi/180)^2);
% plot the results
figure(1)
box on
grid on
plot(xc, yc)
axis equal
axis off
xlim([-180 180])
ylim([-180 180])
hold on
plot(xc_m, yc_m, 'k')
plot(xc_p', yc_p', 'k')
% plot the cities
plot(xc_Stu, yc_Stu, '*')
text(xc_Stu, yc_Stu,'Stuttgart')

plot(xc_Tai, yc_Tai, '*')
text(xc_Tai, yc_Tai,'Taipei')

plot(xc_NY, yc_NY, '*')
text(xc_NY, yc_NY, 'New York')

plot(xc_Per, yc_Per, '*')
text(xc_Per, yc_Per, 'Perth')
% plot the line between two cities
plot([xc_Stu xc_Tai], [yc_Stu yc_Tai], 'linewidth', 2)
plot([xc_Stu xc_NY], [yc_Stu yc_NY], 'linewidth', 2)
plot([xc_Stu xc_Per], [yc_Stu yc_Per], 'linewidth', 2)
title('Cylindrical Projection', 'fontsize', 16)
%% Miller cylindrical projection

long_mc = long;
lat_mc = lat;
% initial value
lambda_init = [-180: 30: 180];
phi_init    = [-90: 10: 90];

% meridians 
[lambda, phi] = meshgrid(lambda_init, linspace(min(phi_init), max(phi_init), 40));
% parallels
[Lambda, Phi] = meshgrid(linspace(min(lambda_init), max(lambda_init), 40), phi_init);

% central coordinate in Miller cylindrical projection
[xmc, ymc]             = miller_cylindrical(long_mc, lat_mc, lambda0, phi0);
[xmc_m, ymc_m]         = miller_cylindrical(lambda, phi, lambda0, phi0);
[xmc_p, ymc_p]         = miller_cylindrical(Lambda, Phi, lambda0, phi0);

% cities coordinate (Stuttgart, Taipei, New York, Perth) in Miller cylindrical projection
[xmc_Stu, ymc_Stu]     = miller_cylindrical(long_Stuttgart, lat_Stuttgart, lambda0, phi0);
[xmc_Tai, ymc_Tai]     = miller_cylindrical(long_Taipei, lat_Taipei, lambda0, phi0);
[xmc_NY, ymc_NY]       = miller_cylindrical(long_NewYork, lat_NewYork, lambda0, phi0);
[xmc_Per, ymc_Per]     = miller_cylindrical(long_Perth, lat_Perth, lambda0, phi0);

% compute the distance
dm_Tai2Stu = sqrt(((xmc_Tai - xmc_Stu)*pi/180)^2 + ((ymc_Tai - ymc_Stu)*pi/180)^2);
dm_NY2Stu = sqrt(((xmc_NY - xmc_Stu)*pi/180)^2 + ((ymc_NY - ymc_Stu)*pi/180)^2);
dm_Per2Stu = sqrt(((xmc_Per - xmc_Stu)*pi/180)^2 + ((ymc_Per - ymc_Stu)*pi/180)^2);
% plot the results
figure(2)
box on
grid on
plot(xmc, ymc)
axis equal
axis off
xlim([-180 180])
ylim([-180 180])
hold on
plot(xmc_m, ymc_m, 'k')
plot(xmc_p', ymc_p', 'k')
% plot the cities
plot(xmc_Stu, ymc_Stu, '*')
text(xmc_Stu, ymc_Stu,'Stuttgart')

plot(xmc_Tai, ymc_Tai, '*')
text(xmc_Tai, ymc_Tai,'Taipei')

plot(xmc_NY, ymc_NY, '*')
text(xmc_NY, ymc_NY, 'New York')

plot(xmc_Per, ymc_Per, '*')
text(xmc_Per, ymc_Per, 'Perth')
% plot the line between two cities
plot([xmc_Stu xmc_Tai], [ymc_Stu ymc_Tai], 'linewidth', 2)
plot([xmc_Stu xmc_NY], [ymc_Stu ymc_NY], 'linewidth', 2)
plot([xmc_Stu xmc_Per], [ymc_Stu ymc_Per], 'linewidth', 2)
title('Miller Cylindrical Projection', 'fontsize', 16)



