function [x, y] = gnomonic(lambda, phi, lambda0, phi1)

% gnomonic inserts specific value in order to compute the coordinates in
% gnomonic projection
%          
% HOW     
%     [x, y] = gnomonic(lambda, phi, lambda0, phi1)
%
% IN  
%     lambda  - longtitude values
%     phi     - latitude values 
%     lambda0 - lambda value in central point
%     phi1    - phi value in central point
% OUT 
%     x   - x coordinate in gnomonic projection
%     y   - y coordinate in gnomonic projection
%
%-----------------------------------------------------------------------
% Yu-Hao Chiang         University of Stuttgart               04/12/2020
%-----------------------------------------------------------------------
% Here we go
% c is the angular distance of the point (x,y) from the center of the projection
cos_cd = sind(phi1).*sind(phi) + cosd(phi1).*cosd(phi).*cosd(lambda - lambda0);
x = ((cosd(phi).*sind(lambda - lambda0))./cos_cd);
y = ((cosd(phi1).*sind(phi) - sind(phi1).*cosd(phi).*cosd(lambda - lambda0))./cos_cd);



end