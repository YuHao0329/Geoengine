function [x, y] = stereographic(lambda, phi, lambda0, phi1)

% stereographic inserts specific value in order to compute the coordinates in
% stereographic projection
%          
% HOW     
%     [x, y] = stereographic(long, lat, lambda0, phi0)
%
% IN  
%     lambda  - longtitude values
%     phi     - latitude values 
%     lambda0 - lambda value in central point
%     phi1    - phi value in central point
% OUT 
%     x   - x coordinate in stereographic projection
%     y   - y coordinate in stereographic projection
%
%-----------------------------------------------------------------------
% Yu-Hao Chiang         University of Stuttgart               05/12/2020
%-----------------------------------------------------------------------
% Here we go
lambda = lambda / 180 * pi; % [degree to rad]
phi = phi / 180 * pi;       % [degree to rad]
% We define the conic section is circle
e = 0;        
% Equatorial radius [Re] 
Re = 6378000;
% conformal latitude [chi]
chi = 2 .* atan( ( tan(1/4*pi + 1/2*phi) ) .* ( (1 - e.*sin(phi))./(1 + e.*sin(phi)) ).^(e/2) ) - 1/2*pi;
R = Re .* cos(phi) ./ ( (1 - e^2.*sin(phi).^2) .* cos(chi) );   
k = (2*R)./(1 + sin(phi1).*sin(phi) + cos(phi1).*cos(phi).*cos(lambda - lambda0));
x = k .* cos(phi) .* sin(lambda - lambda0);
y = k .* (cos(phi1).*sin(phi) - sin(phi1).*cos(phi).*cos(lambda - lambda0));

end