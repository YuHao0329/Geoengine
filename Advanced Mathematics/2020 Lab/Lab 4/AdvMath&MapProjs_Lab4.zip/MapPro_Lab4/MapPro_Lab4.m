%% Map projection Lab 4
%% Yu-Hao Chiang 3443130
close all
clear all
clc
%% Prepare data
% Obtain long, lat coastline 
load('coast.mat')
[long,lat] = jump2nan(long, 180, lat);

% central point
lambda0 = 0;
phi1 = 0;

% coordinate of the cities
% Stuttgart
long_Stuttgart = 9.183333;       %[degree]
lat_Stuttgart  = 48.783333;      %[degree]

% Taipei
long_Taipei = 121.597366;        %[degree]
lat_Taipei  =  25.105497;        %[degree]

% New York
long_NewYork = -73.935242;       %[degree]
lat_NewYork = 40.730610;         %[degree]

% Perth
long_Perth = 115.857048;         %[degree]
lat_Perth = -31.953512;          %[degree]

% Rio de Janeiro
long_Rio = -43.1963888;          %[degree]
lat_Rio = -22.9083333;           %[degree]

% Cape Town
long_Cape = 18.36666;            %[degree]
lat_Cape = -33.91666;            %[degree]

%% Gnomonic Projection
long_g = long;
lat_g = lat;
long_g(abs(long_g) >= 75) = NaN;
lat_g(abs(lat_g) >= 75) = NaN;

% initial value
lambda_init_g = [-75: 15: 75];
phi_init_g    = [-75: 15: 75];

% meridians 
[lambda, phi] = meshgrid(lambda_init_g, linspace(min(phi_init_g), max(phi_init_g), 40));
% parallels
[Lambda, Phi] = meshgrid(linspace(min(lambda_init_g), max(lambda_init_g), 40), phi_init_g);

% central coordinate in gnomonic projection
[xg, yg]             = gnomonic(long_g, lat_g, lambda0, phi1);
[xg_m, yg_m]         = gnomonic(lambda, phi, lambda0, phi1);
[xg_p, yg_p]         = gnomonic(Lambda, Phi, lambda0, phi1);

% cities coordinate (Stuttgart, Taipei, New York, Perth) in cylindrical projection
[xg_Stu, yg_Stu]     = gnomonic(long_Stuttgart, lat_Stuttgart, lambda0, phi1);
[xg_Rio, yg_Rio]     = gnomonic(long_Rio, lat_Rio, lambda0, phi1);
[xg_NY, yg_NY]       = gnomonic(long_NewYork, lat_NewYork, lambda0, phi1);
[xg_Cape, yg_Cape]   = gnomonic(long_Cape, lat_Cape, lambda0, phi1);

% compute the distance
dg_Rio2Stu = sqrt(((xg_Rio - xg_Stu)*pi/180)^2 + ((yg_Rio - yg_Stu)*pi/180)^2);
dg_NY2Stu = sqrt(((xg_NY - xg_Stu)*pi/180)^2 + ((yg_NY - yg_Stu)*pi/180)^2);
dg_Cape2Stu = sqrt(((xg_Cape - xg_Stu)*pi/180)^2 + ((yg_Cape - yg_Stu)*pi/180)^2);

% plot the results
figure(1)
box on
grid on
plot(xg, yg)
axis equal
axis off
% xlim([-180 180])
% ylim([-180 180])
hold on
plot(xg_m, yg_m, 'color',[0.5,0.5,0.5])
plot(xg_p', yg_p', 'color',[0.5,0.5,0.5])
% plot the cities
plot(xg_Stu, yg_Stu, '*')
text(xg_Stu, yg_Stu,'Stuttgart')

plot(xg_Rio, yg_Rio, '*')
text(xg_Rio, yg_Rio,'Rio de Janeiro')

plot(xg_NY, yg_NY, '*')
text(xg_NY, yg_NY, 'New York')

plot(xg_Cape, yg_Cape, '*')
text(xg_Cape, yg_Cape, 'Cape Town')

% plot the line between two cities
plot([xg_Stu xg_Rio], [yg_Stu yg_Rio], 'linewidth', 2)
plot([xg_Stu xg_NY], [yg_Stu yg_NY], 'linewidth', 2)
plot([xg_Stu xg_Cape], [yg_Stu yg_Cape], 'linewidth', 2)
title('Gnomonic Projection', 'fontsize', 16)

%% Orthographic Projection

% initial value
lambda_init_o = [-180: 30: 180];
phi_init_o    = [-90: 15: 90];


% meridians 
[lambda, phi] = meshgrid(lambda_init_o, linspace(min(phi_init_o), max(phi_init_o), 40));
% parallels
[Lambda, Phi] = meshgrid(linspace(min(lambda_init_o), max(lambda_init_o), 40), phi_init_o);

% central coordinate in orthographic projection
[xo, yo]             = orthographic(long, lat, lambda0, phi1);
[xo_m, yo_m]         = orthographic(lambda, phi, lambda0, phi1);
[xo_p, yo_p]         = orthographic(Lambda, Phi, lambda0, phi1);

% cities coordinate (Stuttgart, Taipei, New York, Perth) in cylindrical projection
[xo_Stu, yo_Stu]     = orthographic(long_Stuttgart, lat_Stuttgart, lambda0, phi1);
[xo_Rio, yo_Rio]     = orthographic(long_Rio, lat_Rio, lambda0, phi1);
[xo_NY, yo_NY]       = orthographic(long_NewYork, lat_NewYork, lambda0, phi1);
[xo_Per, yo_Per]     = orthographic(long_Perth, lat_Perth, lambda0, phi1);

% compute the distance
do_Rio2Stu = sqrt(((xo_Rio - xo_Stu)*pi/180)^2 + ((yo_Rio - yo_Stu)*pi/180)^2);
do_NY2Stu = sqrt(((xo_NY - xo_Stu)*pi/180)^2 + ((yo_NY - yo_Stu)*pi/180)^2);
do_Per2Stu = sqrt(((xo_Per - xo_Stu)*pi/180)^2 + ((yo_Per - yo_Stu)*pi/180)^2);

% plot the results
figure(2)
box on
grid on
plot(xo, yo)
axis equal
axis off
xlim([-180 180])
ylim([-180 180])
hold on
plot(xo_m, yo_m, 'color',[0.5,0.5,0.5])
plot(xo_p', yo_p', 'color',[0.5,0.5,0.5])
% plot the cities
plot(xo_Stu, yo_Stu, '*')
text(xo_Stu, yo_Stu,'Stuttgart')

plot(xo_Rio, yo_Rio, '*')
text(xo_Rio, yo_Rio,'Rio de Janeiro')

plot(xo_NY, yo_NY, '*')
text(xo_NY, yo_NY, 'New York')

plot(xo_Per, yo_Per, '*')
text(xo_Per, yo_Per, 'Perth')

% plot the line between two cities
plot([xo_Stu xo_Rio], [yo_Stu yo_Rio], 'linewidth', 2)
plot([xo_Stu xo_NY], [yo_Stu yo_NY], 'linewidth', 2)
plot([xo_Stu xo_Per], [yo_Stu yo_Per], 'linewidth', 2)
title('Orthographic Projection', 'fontsize', 16)
%% Stereographic Projection

long_s = long;
lat_s = lat;
long_s(abs(long_s) >= 170) = NaN;
lat_s(abs(lat_s) >= 180) = NaN;
% initial value
lambda_init_s = [-170: 10: 170];
phi_init_s    = [-180: 10: 180];

% meridians 
[lambda, phi] = meshgrid(lambda_init_s, linspace(min(phi_init_s), max(phi_init_s), 100));
% parallels
[Lambda, Phi] = meshgrid(linspace(min(lambda_init_s), max(lambda_init_s), 100), phi_init_s);

% central coordinate in stereographic projection
[xs, ys]             = stereographic(long_s, lat_s, lambda0, phi1);
[xs_m, ys_m]         = stereographic(lambda, phi, lambda0, phi1);
[xs_p, ys_p]         = stereographic(Lambda, Phi, lambda0, phi1);

% cities coordinate (Stuttgart, Taipei, New York, Perth) in cylindrical projection
[xs_Stu, ys_Stu]     = stereographic(long_Stuttgart, lat_Stuttgart, lambda0, phi1);
[xs_Rio, ys_Rio]     = stereographic(long_Rio, lat_Rio, lambda0, phi1);
[xs_NY, ys_NY]       = stereographic(long_NewYork, lat_NewYork, lambda0, phi1);
[xs_Cape, ys_Cape]     = stereographic(long_Cape, lat_Cape, lambda0, phi1);

% compute the distance
ds_Rio2Stu = sqrt(((xs_Rio - xs_Stu)*pi/180)^2 + ((ys_Rio - ys_Stu)*pi/180)^2);
ds_NY2Stu = sqrt(((xs_NY - xs_Stu)*pi/180)^2 + ((ys_NY - ys_Stu)*pi/180)^2);
ds_Cape2Stu = sqrt(((xs_Cape - xs_Stu)*pi/180)^2 + ((ys_Cape - ys_Stu)*pi/180)^2);

% plot the results
figure(3)
box on
grid on
plot(xs, ys)
axis equal
axis off
hold on
plot(xs_m, ys_m, 'color',[0.5,0.5,0.5])
plot(xs_p', ys_p','color',[0.5,0.5,0.5])
% plot the cities
plot(xs_Stu, ys_Stu, '*')
text(xs_Stu, ys_Stu,'Stuttgart')

plot(xs_Rio, ys_Rio, '*')
text(xs_Rio, ys_Rio,'Rio de Janeiro')

plot(xs_NY, ys_NY, '*')
text(xs_NY, ys_NY, 'New York')

plot(xs_Cape, ys_Cape, '*')
text(xs_Cape, ys_Cape, 'Cape Town')

% plot the line between two cities
plot([xs_Stu xs_Rio], [ys_Stu ys_Rio], 'linewidth', 2)
plot([xs_Stu xs_NY], [ys_Stu ys_NY], 'linewidth', 2)
plot([xs_Stu xs_Cape], [ys_Stu ys_Cape], 'linewidth', 2)
title('Stereographic Projection', 'fontsize', 16)
