function [x, y] = orthographic(lambda, phi, lambda0, phi1)

% orthographic inserts specific value in order to compute the coordinates in
% orthographic projection
%          
% HOW     
%     [x, y] = orthographic(lambda, phi, lambda0, phi0)
%
% IN  
%     lambda  - longtitude values
%     phi     - latitude values 
%     lambda0 - lambda value in central point
%     phi1    - phi value in central point
% OUT 
%     x   - x coordinate in orthographic projection
%     y   - y coordinate in orthographic projection
%
%-----------------------------------------------------------------------
% Yu-Hao Chiang         University of Stuttgart               05/12/2020
%-----------------------------------------------------------------------
% Here we go
x = (cosd(phi).*sind(lambda - lambda0))/pi*180;
y = (cosd(phi1).*sind(phi) - sind(phi1).*cosd(phi).*cosd(lambda - lambda0))/pi*180;



end