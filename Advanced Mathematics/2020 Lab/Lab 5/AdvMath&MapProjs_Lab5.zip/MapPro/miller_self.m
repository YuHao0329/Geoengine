function [x, y] = miller_self(Lambda, Phi, lambda0, phi1)
% https://mathworld.wolfram.com/MillerCylindricalProjection.html

x = Lambda-lambda0;
y = 5/4 .* log(tan(1/4.*pi + 2/5 .* Phi));
end