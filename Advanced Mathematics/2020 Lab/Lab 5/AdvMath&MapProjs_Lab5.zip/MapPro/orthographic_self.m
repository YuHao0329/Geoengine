function [x, y] = orthographic_self(Lambda, Phi, lambda0, phi1)
% https://mathworld.wolfram.com/OrthographicProjection.html

x = cos(Phi).*sin(Lambda-lambda0);
y = cos(phi1).*sin(Phi) - sin(phi1).*cos(Phi).*cos(Lambda-lambda0);

end