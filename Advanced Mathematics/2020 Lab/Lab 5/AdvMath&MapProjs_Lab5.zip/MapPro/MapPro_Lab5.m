%% Map Projection Lab5
%% Yu-Hao Chiang 3443130
close all
clear all
clc
%% Task 1
% sphere
syms R Phi Lambda
x = R * cos(Phi) * cos(Lambda);
y = R * cos(Phi) * sin(Lambda);
z = R * sin(Phi);
X = [x; y; z];
% Tangent vector
G1 = simplify(diff(X, Lambda))
G2 = simplify(diff(X, Phi))
% Normal vector
G3 = simplify(cross(G1, G2) / norm(cross(G1, G2)))
%% Task 2
% G_bar
G_bar = [dot(G1, G1)  dot(G1, G2);
         dot(G2, G1)  dot(G2, G2)];
G_bar = simplify(G_bar)
% Miller projection
syms lambda phi lambda0 phi0
[x_miller, y_miller] = miller_self(lambda, phi, lambda0, phi0);
% Jacobian matrix in miller projection
J_bar_miller = [diff(x_miller, lambda) diff(x_miller, phi);
                diff(y_miller, lambda) diff(y_miller, phi)]
            
% Orthographic projection
[x_ortho, y_ortho] = orthographic_self(lambda, phi, lambda0, phi0);
% Jacobian matrix in Orthographic projection
J_bar_ortho = [diff(x_ortho, lambda) diff(x_ortho, phi);
               diff(y_ortho, lambda) diff(y_ortho, phi)]
%% Task 3
% The parameters for the sphere E, F, G
E = simplify(dot(diff(X, Lambda), diff(X, Lambda)))
F = simplify(dot(diff(X, Phi), diff(X, Lambda)))
G = simplify(dot(diff(X, Phi), diff(X, Phi)))

% The parameters for the Miller projection e, f, g
syms z_miller
e = (diff(x_miller, lambda))^2 + (diff(y_miller, lambda))^2 + (diff(z_miller, lambda))^2
f = diff(x_miller, lambda) * diff(x_miller, phi) + diff(y_miller, lambda) * diff(y_miller, phi) + diff(z, lambda) * diff(z, phi)
g = (diff(x_miller, phi))^2 + (diff(y_miller, phi))^2 + (diff(z, phi))^2

% Calculate the distance
syms d_Lambda d_Phi d_lambda d_phi
dS2 = E*d_Lambda^2 + 2*F*d_Lambda*d_Phi + G*d_Phi^2;
ds2 = e*d_lambda^2 + 2*f*d_lambda*d_Phi + g*d_phi^2;
% scaling factor 
m2 = ds2 / dS2;
%% Task 4
clear
load coast.mat
[long, lat] = jump2nan(long, 180, lat);
%[degree]
Stuttgart     = [9.183, 48.783]; 
Paris         = [2.352, 48.857];
Oslo          = [10.752, 59.914];
Abidjan       = [-4.033, 5.317];
Accra         = [-0.216, 5.55];
Bawku         = [-0.24, 11.06];
Dikson        = [80.517, 73.5];
Nowly_Urengoi = [76.683, 66.083];
Salechard     = [66.633, 66.533];
Name = ['Stuttgart'; 'Paris'; 'Oslo'; 'Abidjan'; 'Accra'; 'Bawku'; 'Dikson'; "Nowly Urengoi"; 'Salechard'];
City = [Stuttgart; Paris; Oslo; Abidjan; Accra; Bawku; Dikson; Nowly_Urengoi; Salechard];
% cnetral point
lambda_0 = 0;
phi_0    = 0;
% Transform the locations below using Miller projection 
[x_coast_miller, y_coast_miller] = miller_self(deg2rad(long), deg2rad(lat), lambda_0, phi_0);
[x_city_miller, y_city_miller] = miller_self(deg2rad(City(:, 1)), deg2rad(City(:, 2)), lambda_0, phi_0);
location_miller = [x_city_miller  y_city_miller];
% Calculate the Euclidean distances in Miller projection
d_miller_Stu2Par  = norm(location_miller(2,:) - location_miller(1,:));  % the distance between Stuttgart and Paris
d_miller_Stu2Oslo = norm(location_miller(3,:) - location_miller(1,:));  % the distance between Stuttgart and Oslo
d_miller_Acc2Abi  = norm(location_miller(4,:) - location_miller(5,:));  % the distance between Accra and Abidjan
d_miller_Acc2Baw  = norm(location_miller(6,:) - location_miller(5,:));  % the distance between Accra and Bawku
d_miller_Now2Dik  = norm(location_miller(7,:) - location_miller(8,:));  % the distance between Nowly Urengoi and Dikson
d_miller_Now2Sal  = norm(location_miller(9,:) - location_miller(8,:));  % the distance between Nowly Urengoi and Salechard
d_miller = [d_miller_Stu2Par; d_miller_Stu2Oslo; d_miller_Acc2Abi; d_miller_Acc2Baw; d_miller_Now2Dik; d_miller_Now2Sal];
% Calculate the currently specified distances on the sphere
% [arclen] = distance(lat1,lon1,lat2,lon2)
arclen_Stu2Par  = distance(Paris(2), Paris(1), Stuttgart(2), Stuttgart(1));                  % the arclength between Stuttgart and Paris
arclen_Stu2Oslo = distance(Oslo(2), Oslo(1), Stuttgart(2), Stuttgart(1));                    % the arclength between Stuttgart and Oslo
arclen_Acc2Abi  = distance(Abidjan(2), Abidjan(1), Accra(2), Accra(1));                      % the arclength between Accra and Abidjan
arclen_Acc2Baw  = distance(Bawku(2), Bawku(1), Accra(2), Accra(1));                          % the arclength between Accra and Bawku
arclen_Now2Dik  = distance(Dikson(2), Dikson(1), Nowly_Urengoi(2), Nowly_Urengoi(1));        % the arclength between Nowly Urengoi and Dikson
arclen_Now2Sal  = distance(Salechard(2), Salechard(1), Nowly_Urengoi(2), Nowly_Urengoi(1));  % the arclength between Nowly Urengoi and Salechard
arclen = [arclen_Stu2Par; arclen_Stu2Oslo; arclen_Acc2Abi; arclen_Acc2Baw; arclen_Now2Dik; arclen_Now2Sal];
% Compare the ratios
ratios_miller = d_miller ./ arclen;

% Transform the locations below using Orthographic projection 
[x_coast_ortho, y_coast_ortho] = orthographic_self(deg2rad(long), deg2rad(lat), lambda_0, phi_0);
[x_city_ortho, y_city_ortho] = orthographic_self(deg2rad(City(:, 1)), deg2rad(City(:, 2)), lambda_0, phi_0);
location_ortho = [x_city_ortho  y_city_ortho];
% Calculate the Euclidean distances in Orthographic projection
d_ortho_Stu2Par  = norm(location_ortho(2,:) - location_ortho(1,:));  % the distance between Stuttgart and Paris
d_ortho_Stu2Oslo = norm(location_ortho(3,:) - location_ortho(1,:));  % the distance between Stuttgart and Oslo
d_ortho_Acc2Abi  = norm(location_ortho(4,:) - location_ortho(5,:));  % the distance between Accra and Abidjan
d_ortho_Acc2Baw  = norm(location_ortho(6,:) - location_ortho(5,:));  % the distance between Accra and Bawku
d_ortho_Now2Dik  = norm(location_ortho(7,:) - location_ortho(8,:));  % the distance between Nowly Urengoi and Dikson
d_ortho_Now2Sal  = norm(location_ortho(9,:) - location_ortho(8,:));  % the distance between Nowly Urengoi and Salechard
d_ortho = [d_ortho_Stu2Par; d_ortho_Stu2Oslo; d_ortho_Acc2Abi; d_ortho_Acc2Baw; d_ortho_Now2Dik; d_ortho_Now2Sal];

% Compare the ratios
ratios_ortho = d_ortho ./ arclen;

% Plot the results
figure
plot(x_coast_miller, y_coast_miller)
hold on
axis equal
axis off
plot(x_city_miller, y_city_miller, 'g*')
plot([location_miller(1,1) location_miller(2,1)], [location_miller(1,2) location_miller(2,2)],'linewidth', 2) % the distance between Stuttgart and Paris
plot([location_miller(1,1) location_miller(3,1)], [location_miller(1,2) location_miller(3,2)],'linewidth', 2) % the distance between Stuttgart and Oslo
plot([location_miller(4,1) location_miller(5,1)], [location_miller(4,2) location_miller(5,2)],'linewidth', 2) % the distance between Accra and Abidjan
plot([location_miller(6,1) location_miller(5,1)], [location_miller(6,2) location_miller(5,2)],'linewidth', 2) % the distance between Accra and Bawku
plot([location_miller(7,1) location_miller(8,1)], [location_miller(7,2) location_miller(8,2)],'linewidth', 2) % the distance between Nowly Urengoi and Dikson
plot([location_miller(9,1) location_miller(8,1)], [location_miller(9,2) location_miller(8,2)],'linewidth', 2) % the distance between Nowly Urengoi and Salechard
text(x_city_miller, y_city_miller, Name)
title('Euclidean distance in Miller projection','fontsize', 16)

% In order to compute the great circle track in projection, we need to use
% the original coordinates to transform into projection coordinates.
Locations = [Stuttgart, Paris;
             Stuttgart, Oslo;
                 Accra, Abidjan;
                 Accra, Bawku;
         Nowly_Urengoi, Dikson;
         Nowly_Urengoi, Salechard];
track_lon_miller = zeros(100, 6);
track_lat_miller = zeros(100, 6);
track_x_miller = zeros(100, 6);
track_y_miller = zeros(100, 6);
for i = 1:6
    [track_lat_miller(:, i), track_lon_miller(:, i)] = track2(Locations(i, 2), Locations(i, 1), Locations(i, 4), Locations(i, 3));
    [track_x_miller(:, i), track_y_miller(:, i)]     = miller_self(deg2rad(track_lon_miller(:, i)), deg2rad(track_lat_miller(:, i)), lambda_0, phi_0);
end
figure
plot(x_coast_miller, y_coast_miller)
hold on
axis equal
axis off
scatter(x_city_miller, y_city_miller, 'g*')
plot(track_x_miller, track_y_miller, 'r-', 'linewidth', 2)
text(x_city_miller, y_city_miller, Name)     
title('Great circle track in Miller projection','fontsize', 16)

figure
plot(x_coast_ortho, y_coast_ortho)
hold on
axis equal
axis off
plot(x_city_ortho, y_city_ortho, 'g*')
plot([location_ortho(1,1) location_ortho(2,1)], [location_ortho(1,2) location_ortho(2,2)],'linewidth', 2) % the distance between Stuttgart and Paris
plot([location_ortho(1,1) location_ortho(3,1)], [location_ortho(1,2) location_ortho(3,2)],'linewidth', 2) % the distance between Stuttgart and Oslo
plot([location_ortho(4,1) location_ortho(5,1)], [location_ortho(4,2) location_ortho(5,2)],'linewidth', 2) % the distance between Accra and Abidjan
plot([location_ortho(6,1) location_ortho(5,1)], [location_ortho(6,2) location_ortho(5,2)],'linewidth', 2) % the distance between Accra and Bawku
plot([location_ortho(7,1) location_ortho(8,1)], [location_ortho(7,2) location_ortho(8,2)],'linewidth', 2) % the distance between Nowly Urengoi and Dikson
plot([location_ortho(9,1) location_ortho(8,1)], [location_ortho(9,2) location_ortho(8,2)],'linewidth', 2) % the distance between Nowly Urengoi and Salechard
text(x_city_ortho, y_city_ortho, Name)
title('Euclidean distance in Orthographic projection','fontsize', 16)

% In order to compute the great circle track in projection, we need to use
% the original coordinates to transform into projection coordinates.
track_lon_ortho = zeros(100, 6);
track_lat_ortho = zeros(100, 6);
track_x_ortho = zeros(100, 6);
track_y_ortho = zeros(100, 6);
for i = 1:6
    [track_lat_ortho(:, i), track_lon_ortho(:, i)] = track2(Locations(i, 2), Locations(i, 1), Locations(i, 4), Locations(i, 3));
    [track_x_ortho(:, i), track_y_ortho(:, i)]     = orthographic_self(deg2rad(track_lon_ortho(:, i)), deg2rad(track_lat_ortho(:, i)), lambda_0, phi_0);
end
figure
plot(x_coast_ortho, y_coast_ortho)
hold on
axis equal
axis off
scatter(x_city_ortho, y_city_ortho, 'g*')
plot(track_x_ortho, track_y_ortho, 'r-', 'linewidth', 2)
text(x_city_ortho, y_city_ortho, Name)
title('Great circle track in Orthographic projection','fontsize', 16)