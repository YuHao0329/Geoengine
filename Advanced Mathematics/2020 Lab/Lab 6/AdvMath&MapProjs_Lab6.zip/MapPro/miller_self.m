function [x, y] = miller_self(Lambda, Phi, lambda0, phi1)
% https://mathworld.wolfram.com/MillerCylindricalProjection.html

x = Lambda.*pi./180-lambda0.*pi./180;
y = 5/4 .* log(tan(1/4.*pi + 2/5 .* Phi.*pi./180));

end