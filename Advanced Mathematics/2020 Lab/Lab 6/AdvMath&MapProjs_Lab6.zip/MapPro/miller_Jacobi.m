function J = miller_Jacobi(lambda, phi)

lambda = lambda.*pi./180;
phi = phi.*pi./180;

J = [1, 0;
     0, 1./(2.*tan(pi/4+2/5.*phi).*cos(pi/4+2/5.*phi).^2)];

end