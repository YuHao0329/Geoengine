function [x, y] = orthographic_self(Lambda, Phi, lambda0, phi1)
% https://mathworld.wolfram.com/OrthographicProjection.html

x = cosd(Phi).*sind(Lambda-lambda0);
y = cosd(phi1).*sind(Phi) - sind(phi1).*cosd(Phi).*cosd(Lambda-lambda0);

end