%% Map Projection Lab6
%% Yu-Hao Chiang 3443130
close all
clear all
clc
%% Prepare data
% Obtain long, lat coastline 
load('coast.mat')
long(long >= 180) = long(long >= 180) - 360;
[long,lat] = jump2nan(long, 180, lat);
R = 1;        % radius
sf = 0.07;    % scaling factor 
% central point
lambda0 = 0;
phi0 = 0;
%% Task 1 Miller projection
% define longitude and latitude grid
lambda_init = [-180: 10: 180];
phi_init = [-90: 10: 90];
lambda_init_tissot = [-180: 30: 180];
phi_init_tissot = [-60: 30: 60];

% meridians 
[lambda_m, phi_m] = meshgrid(lambda_init, linspace(min(phi_init), max(phi_init), 40));
% parallels
[lambda_p, phi_p] = meshgrid(linspace(min(lambda_init), max(lambda_init), 40), phi_init);

[x_miller, y_miller]   = miller_self(long, lat, lambda0, phi0);
[mx_miller, my_miller] = miller_self(lambda_m, phi_m, lambda0, phi0);
[px_miller, py_miller] = miller_self(lambda_p', phi_p', lambda0, phi0);

% plot the result
figure
hold on 
axis equal
box on
plot(x_miller, y_miller, 'b')
plot(mx_miller, my_miller, 'k')
plot(px_miller, py_miller, 'k')
% tissot ellipses
for lambda = lambda_init_tissot
    for phi = phi_init_tissot
        % define cneter of the tissot ellipse
        [x, y] = miller_self(lambda, phi, lambda0, phi0);
        % compute the foundational form (real)
        G = R^2 * [cos(phi * pi/180)^2  0;
                                0       1];
        % compute the foundational form (image)
        g = eye(2);
        % Jacobian matrix
        J = miller_Jacobi(lambda, phi);
        % Cauchy-Green deformation tensor
        C = J' * g * J;
        % determine F D
        [F D] = eig(C, G);
        % transform on the map
        f = J * F;
        % determine the tissot semi-axis with D 
        lambda1 = sqrt(D(2,2));
        lambda2 = sqrt(D(1,1));
        % determine the tissot orientation
        beta = atan2(f(2,2), f(1,2));
        % plot the ellipse
        % if r=1, green circle (no distortion), else red
        if  lambda1(:) == lambda2(:)
            ind = lambda1(:);
            yline(y(ind), 'g')
            ellipse(sf * lambda1(ind), sf * lambda2(ind), beta(ind), x(ind), y(ind), 'g');
        else 
            yline(y, 'r')
            ellipse(sf * lambda1, sf * lambda2, beta, x, y, 'r');
        end
    end
end
title('Miller projection', 'fontsize', 16)
 
%% Task 2 Orthographic projection
% Obtain long, lat coastline 
load('coast.mat')
long(abs(long) >= 90) = NaN;
[long,lat] = jump2nan(long, 180, lat);
R = 1;        % radius
sf = 0.07;    % scaling factor 
% central point
lambda0 = 0;
phi0 = 0;
% define longitude and latitude grid
lambda_init = [-180: 10: 180];
phi_init = [-90: 10: 90];
lambda_init_tissot = [-180: 30: 180];
phi_init_tissot = [-60: 30: 60];

% meridians 
[lambda_m, phi_m] = meshgrid(lambda_init, linspace(min(phi_init), max(phi_init), 40));
% parallels
[lambda_p, phi_p] = meshgrid(linspace(min(lambda_init), max(lambda_init), 40), phi_init);

[x_ortho, y_ortho]   = orthographic_self(long, lat, lambda0, phi0);
[mx_ortho, my_ortho] = orthographic_self(lambda_m, phi_m, lambda0, phi0);
[px_ortho, py_ortho] = orthographic_self(lambda_p', phi_p', lambda0, phi0);

% plot the result
figure
hold on 
box on
axis equal
plot(x_ortho, y_ortho, 'b')
plot(mx_ortho, my_ortho, 'k')
plot(px_ortho, py_ortho, 'k')
% tissot ellipses
for lambda = lambda_init_tissot
    for phi = phi_init_tissot
        % define cneter of the tissot ellipse
        [x, y] = orthographic_self(lambda, phi, lambda0, phi0);
        % compute the fundational form (real)
        G = R^2 * [cos(phi * pi/180)^2  0;
                                0       1];
        % compute the fundational form (image)
        g = eye(2);
        % Jacobian matrix
        J = orthographic_Jacobi(lambda, phi, lambda0, phi0);
        % Cauchy-Green deformation tensor
        C = J' * g * J;
        % determine F D
        [F D] = eig(C, G);
        % transform on the map
        f = J * F;
        % determine the tissot semi-axis with D 
        lambda1 = sqrt(D(2,2));
        lambda2 = sqrt(D(1,1));
        % determine the tissot orientation
        beta = atan2(f(2,2), f(1,2));
        % plot the ellipse
        % if r=1, green circle (no distortion), else red
        if  lambda1(:) == lambda2(:)
            ind = lambda1(:);
            ellipse(sf * lambda1(ind), sf * lambda2(ind), beta(ind), x(ind), y(ind), 'g');
        else 
            ellipse(sf * lambda1, sf * lambda2, beta, x, y, 'r');
        end
    end
end
title('Orthographic projection', 'fontsize', 16)








